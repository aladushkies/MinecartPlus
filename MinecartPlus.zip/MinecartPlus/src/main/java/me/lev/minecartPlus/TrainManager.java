package dev.minecartplus;

import org.bukkit.entity.AbstractMinecart;
import org.bukkit.entity.FurnaceMinecart;

import java.util.*;

/**
 * Manages train chains: leader → follower relationships.
 * Maximum chain length: 8 wagons.
 */
public class TrainManager {

    private static final int MAX_CHAIN_LENGTH = 8;

    // leader → direct follower (one step)
    private final Map<AbstractMinecart, AbstractMinecart> leaderToFollower = new LinkedHashMap<>();

    // -------------------------------------------------------------------------
    // Linking
    // -------------------------------------------------------------------------

    /**
     * Attempts to link {@code follower} behind {@code leader}.
     *
     * @return true if the link was created, false if it would exceed the limit
     *         or create a cycle.
     */
    public boolean link(AbstractMinecart leader, AbstractMinecart follower) {
        if (leader.equals(follower)) return false;
        if (wouldCycle(leader, follower)) return false;

        // Count total wagons that would be in the resulting chain
        AbstractMinecart root = findRoot(leader);
        if (chainLength(root) >= MAX_CHAIN_LENGTH) return false;

        leaderToFollower.put(leader, follower);
        return true;
    }

    /** Removes all links involving this cart (as leader or follower). */
    public void unlink(AbstractMinecart cart) {
        leaderToFollower.remove(cart);
        leaderToFollower.entrySet().removeIf(e -> e.getValue().equals(cart));
    }

    // -------------------------------------------------------------------------
    // Query helpers
    // -------------------------------------------------------------------------

    public boolean isLeader(AbstractMinecart cart) {
        return leaderToFollower.containsKey(cart);
    }

    public boolean isFollower(AbstractMinecart cart) {
        return leaderToFollower.containsValue(cart);
    }

    /** Returns the direct follower of {@code leader}, or null. */
    public AbstractMinecart getFollower(AbstractMinecart leader) {
        return leaderToFollower.get(leader);
    }

    /**
     * Returns the head (root) of the train that contains {@code cart}.
     * The root is the cart that has no leader pointing to it.
     */
    public AbstractMinecart findRoot(AbstractMinecart cart) {
        Set<AbstractMinecart> visited = new HashSet<>();
        AbstractMinecart current = cart;
        while (true) {
            AbstractMinecart parent = findParent(current);
            if (parent == null || visited.contains(parent)) return current;
            visited.add(current);
            current = parent;
        }
    }

    /** Returns all carts in this train in order (root first). */
    public List<AbstractMinecart> getTrainCarts(AbstractMinecart anyCart) {
        AbstractMinecart root = findRoot(anyCart);
        List<AbstractMinecart> chain = new ArrayList<>();
        Set<AbstractMinecart> visited = new HashSet<>();
        AbstractMinecart cur = root;
        while (cur != null && !visited.contains(cur)) {
            chain.add(cur);
            visited.add(cur);
            cur = leaderToFollower.get(cur);
        }
        return chain;
    }

    /**
     * Returns whether {@code anyCart} is in a train whose root is a fuelled
     * FurnaceMinecart.
     */
    public boolean hasFuelledLocomotive(AbstractMinecart anyCart) {
        AbstractMinecart root = findRoot(anyCart);
        if (root instanceof FurnaceMinecart furnace) {
            return furnace.getFuel() > 0;
        }
        return false;
    }

    /** Clears all train data (called on plugin disable). */
    public void clear() {
        leaderToFollower.clear();
    }

    // -------------------------------------------------------------------------
    // Internal helpers
    // -------------------------------------------------------------------------

    private AbstractMinecart findParent(AbstractMinecart cart) {
        for (Map.Entry<AbstractMinecart, AbstractMinecart> entry : leaderToFollower.entrySet()) {
            if (entry.getValue().equals(cart)) return entry.getKey();
        }
        return null;
    }

    private int chainLength(AbstractMinecart root) {
        int count = 0;
        Set<AbstractMinecart> visited = new HashSet<>();
        AbstractMinecart cur = root;
        while (cur != null && !visited.contains(cur)) {
            count++;
            visited.add(cur);
            cur = leaderToFollower.get(cur);
        }
        return count;
    }

    private boolean wouldCycle(AbstractMinecart leader, AbstractMinecart follower) {
        // Check if follower is already an ancestor of leader
        Set<AbstractMinecart> ancestors = new HashSet<>();
        AbstractMinecart cur = leader;
        while (cur != null) {
            if (cur.equals(follower)) return true;
            if (!ancestors.add(cur)) break; // already saw this node
            cur = findParent(cur);
        }
        return false;
    }
}
