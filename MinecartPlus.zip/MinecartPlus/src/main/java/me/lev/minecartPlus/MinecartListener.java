package dev.minecartplus;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerLeashEntityEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.vehicle.VehicleDestroyEvent;
import org.bukkit.event.vehicle.VehicleMoveEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class MinecartListener implements Listener {

    // ---- Constants --------------------------------------------------------
    /** Maximum speed in blocks/second. */
    private static final double MAX_SPEED_BPS = 48.0;
    /** Convert b/s to b/tick (20 ticks = 1 second). */
    private static final double MAX_SPEED_BPT = MAX_SPEED_BPS / 20.0;
    /** Distance threshold before a follower starts catching up. */
    private static final double FOLLOW_DISTANCE = 1.5;
    /** Speed of the follower catch-up (fraction of gap per tick). */
    private static final double FOLLOW_STRENGTH = 0.35;
    /** How fast speed ramps up per tick when accelerating. */
    private static final double ACCEL_RATE = 0.05 / 20.0;   // 0.05 b/s per tick
    /** How fast speed ramps down per tick when decelerating. */
    private static final double DECEL_RATE = 0.10 / 20.0;
    /** Locomotive push multiplier above vanilla FurnaceMinecart. */
    private static final double LOCO_PUSH_MULTIPLIER = 2.5;
    /** How often (in ticks) we send the action-bar update. */
    private static final int ACTION_BAR_INTERVAL = 2;

    // ---- State ------------------------------------------------------------
    /** Pending first-cart selection for coupling: player UUID → first cart. */
    private final Map<UUID, AbstractMinecart> pendingCouple = new HashMap<>();

    /** Per-cart smooth speed tracker (blocks per tick). */
    private final Map<UUID, Double> cartSpeed = new HashMap<>();

    /** Tick counter for action-bar throttling per player. */
    private final Map<UUID, Integer> actionBarTick = new HashMap<>();

    private final MinecartPlusPlugin plugin;
    private final TrainManager trainManager;

    public MinecartListener(MinecartPlusPlugin plugin, TrainManager trainManager) {
        this.plugin = plugin;
        this.trainManager = trainManager;
    }

    // =========================================================================
    // Feature 1 — Coupling with a Lead (Leash)
    // =========================================================================

    /**
     * Bukkit fires {@link PlayerInteractEntityEvent} when right-clicking any
     * entity. We intercept clicks on Minecarts while holding a LEAD.
     */
    @EventHandler(priority = EventPriority.HIGH)
    public void onInteractEntity(PlayerInteractEntityEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;

        Entity clicked = event.getRightClicked();
        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();

        // ---- Furnace Minecart + Lava Bucket → Refuel ----
        if (clicked instanceof FurnaceMinecart furnace && item.getType() == Material.LAVA_BUCKET) {
            event.setCancelled(true);
            refuelLocomotive(player, furnace, item);
            return;
        }

        // ---- Any Minecart + Lead → Coupling ----
        if (clicked instanceof AbstractMinecart targetCart && item.getType() == Material.LEAD) {
            event.setCancelled(true);

            UUID uid = player.getUniqueId();
            AbstractMinecart first = pendingCouple.get(uid);

            if (first == null || !first.isValid()) {
                // First click: remember the cart
                pendingCouple.put(uid, targetCart);
                player.sendActionBar(Component.text(
                        "✔ Первая вагонетка выбрана. Кликни по второй для сцепки.",
                        NamedTextColor.YELLOW));
            } else {
                // Second click: attempt to couple
                pendingCouple.remove(uid);

                if (first.equals(targetCart)) {
                    player.sendActionBar(Component.text(
                            "✘ Нельзя сцепить вагонетку с самой собой.", NamedTextColor.RED));
                    return;
                }

                boolean linked = trainManager.link(first, targetCart);
                if (linked) {
                    // Initialise smooth speed for the leader
                    cartSpeed.putIfAbsent(first.getUniqueId(), 0.0);
                    player.sendMessage(Component.text(
                            "✔ Вагонетки сцеплены! Поезд готов к отправлению.",
                            NamedTextColor.GREEN));
                } else {
                    player.sendMessage(Component.text(
                            "✘ Не удалось сцепить: превышена максимальная длина поезда (8 вагонов) или создаётся петля.",
                            NamedTextColor.RED));
                }
            }
        }
    }

    // =========================================================================
    // Feature 2 — Cruise Control & Speed (Action Bar)
    // =========================================================================

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onVehicleMove(VehicleMoveEvent event) {
        Vehicle vehicle = event.getVehicle();
        if (!(vehicle instanceof AbstractMinecart leader)) return;

        // Only process the root of a chain (or a standalone cart with a rider)
        if (trainManager.isFollower(leader)) return;

        // ---- Locomotive auto-push ----
        applyLocomotivePush(leader);

        // ---- Speed Control for player passengers ----
        Player player = getPlayerPassenger(leader);
        if (player != null) {
            handleSpeedControl(leader, player);
        }

        // ---- Pull followers ----
        pullFollowers(leader);
    }

    /** Smooth acceleration / deceleration driven by where the player looks. */
    private void handleSpeedControl(AbstractMinecart cart, Player player) {
        Vector cartVel = cart.getVelocity();
        double currentSpeedBPT = cartVel.length();

        // Retrieve or init the smooth speed
        double smoothSpeed = cartSpeed.getOrDefault(cart.getUniqueId(), currentSpeedBPT);

        // Direction of player's gaze projected onto XZ plane
        Vector gazeXZ = player.getLocation().getDirection().setY(0).normalize();
        // Normalise cart velocity on XZ plane (if moving)
        Vector cartDir = cartVel.clone().setY(0);
        double cartHorizSpeed = cartDir.length();

        boolean movingForward = false;
        boolean movingBackward = false;

        if (cartHorizSpeed > 0.01 && !gazeXZ.isZero()) {
            cartDir.normalize();
            double dot = gazeXZ.dot(cartDir);
            if (dot > 0.5) movingForward = true;
            else if (dot < -0.5) movingBackward = true;
        }

        if (movingForward) {
            smoothSpeed = Math.min(smoothSpeed + ACCEL_RATE, MAX_SPEED_BPT);
        } else if (movingBackward) {
            smoothSpeed = Math.max(smoothSpeed - DECEL_RATE, 0.0);
        }
        // else: coasting — speed decays naturally via Minecraft friction

        cartSpeed.put(cart.getUniqueId(), smoothSpeed);

        // Apply the target speed by scaling the current velocity direction
        if (cartHorizSpeed > 0.01) {
            Vector targetVel = cartDir.normalize().multiply(smoothSpeed);
            targetVel.setY(cartVel.getY()); // preserve vertical component
            cart.setVelocity(targetVel);
        }

        // Ensure the Purpur max-speed cap is set
        cart.setMaxSpeed(MAX_SPEED_BPT);

        // Action Bar (throttled to every ACTION_BAR_INTERVAL ticks)
        UUID uid = player.getUniqueId();
        int tick = actionBarTick.getOrDefault(uid, 0) + 1;
        if (tick >= ACTION_BAR_INTERVAL) {
            tick = 0;
            double speedBPS = smoothSpeed * 20.0;
            player.sendActionBar(Component.text(
                    "⚡ Скорость: " + String.format("%.1f", speedBPS) + " б/с",
                    NamedTextColor.GOLD));
        }
        actionBarTick.put(uid, tick);
    }

    // =========================================================================
    // Feature 3 — Locomotive (FurnaceMinecart)
    // =========================================================================

    /** Refuel a FurnaceMinecart with a lava bucket. */
    private void refuelLocomotive(Player player, FurnaceMinecart furnace, ItemStack lavaItem) {
        furnace.setFuel(9600); // ~8 minutes of continuous push

        // Replace the lava bucket with an empty bucket
        lavaItem.subtract(1);
        ItemStack bucket = new ItemStack(Material.BUCKET);
        if (lavaItem.getAmount() == 0) {
            player.getInventory().setItemInMainHand(bucket);
        } else {
            // Shouldn't happen (lava buckets stack to 1), but be safe
            player.getInventory().addItem(bucket);
        }

        player.sendMessage(Component.text(
                "🔥 Локомотив заправлен лавой! Поезд готов к движению.",
                NamedTextColor.GOLD));
    }

    /**
     * If the given cart is a fuelled FurnaceMinecart that leads a train,
     * apply an amplified push in the cart's current direction of travel.
     */
    private void applyLocomotivePush(AbstractMinecart leader) {
        if (!(leader instanceof FurnaceMinecart furnace)) return;
        if (furnace.getFuel() <= 0) return;
        if (!trainManager.isLeader(furnace)) return; // only if it actually pulls something

        // FurnaceMinecart push values are set via setPushX/Z.
        // We amplify them by LOCO_PUSH_MULTIPLIER.
        double px = furnace.getPushX();
        double pz = furnace.getPushZ();

        // If no push is set yet, derive from velocity direction
        if (px == 0.0 && pz == 0.0) {
            Vector vel = furnace.getVelocity();
            if (vel.lengthSquared() > 1e-4) {
                Vector dir = vel.clone().setY(0).normalize();
                px = dir.getX();
                pz = dir.getZ();
            }
        }

        furnace.setPushX(px * LOCO_PUSH_MULTIPLIER);
        furnace.setPushZ(pz * LOCO_PUSH_MULTIPLIER);
        furnace.setMaxSpeed(MAX_SPEED_BPT);
    }

    // =========================================================================
    // Follower physics — smooth chain tug
    // =========================================================================

    /**
     * Recursively pull each follower toward its leader using velocity-based
     * smooth interpolation to avoid teleport jerkiness.
     */
    private void pullFollowers(AbstractMinecart leader) {
        AbstractMinecart follower = trainManager.getFollower(leader);
        if (follower == null || !follower.isValid()) return;

        double distance = leader.getLocation().distance(follower.getLocation());
        if (distance > FOLLOW_DISTANCE) {
            Vector toLeader = leader.getLocation().toVector()
                    .subtract(follower.getLocation().toVector());

            // Scale pull strength with distance (further → stronger pull)
            double strength = FOLLOW_STRENGTH * (distance / FOLLOW_DISTANCE);
            strength = Math.min(strength, MAX_SPEED_BPT); // cap at max speed

            Vector pullVelocity = toLeader.normalize().multiply(strength);
            // Preserve some existing momentum for smoothness
            Vector existing = follower.getVelocity().multiply(0.3);
            follower.setVelocity(pullVelocity.add(existing));
            follower.setMaxSpeed(MAX_SPEED_BPT);
        }

        // Recurse to the next wagon in the chain
        pullFollowers(follower);
    }

    // =========================================================================
    // Cleanup — remove destroyed carts from all maps
    // =========================================================================

    @EventHandler(priority = EventPriority.MONITOR)
    public void onVehicleDestroy(VehicleDestroyEvent event) {
        Vehicle vehicle = event.getVehicle();
        if (!(vehicle instanceof AbstractMinecart cart)) return;

        trainManager.unlink(cart);
        cartSpeed.remove(cart.getUniqueId());

        // Clean up any pending couple selection referencing this cart
        pendingCouple.entrySet().removeIf(e -> e.getValue().equals(cart));

        // Clean up passengers' action-bar tickers if they were riding this cart
        Entity passenger = getPlayerPassenger(cart);
        if (passenger instanceof Player player) {
            actionBarTick.remove(player.getUniqueId());
        }
    }

    // =========================================================================
    // Utility
    // =========================================================================

    /** Returns the first Player passenger of the cart, or null. */
    private Player getPlayerPassenger(AbstractMinecart cart) {
        for (Entity passenger : cart.getPassengers()) {
            if (passenger instanceof Player p) return p;
        }
        return null;
    }
}
