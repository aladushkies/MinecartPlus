package dev.minecartplus;

import org.bukkit.plugin.java.JavaPlugin;

public class MinecartPlusPlugin extends JavaPlugin {

    private TrainManager trainManager;

    @Override
    public void onEnable() {
        trainManager = new TrainManager();
        getServer().getPluginManager().registerEvents(new MinecartListener(this, trainManager), this);
        getLogger().info("MinecartPlus включён!");
    }

    @Override
    public void onDisable() {
        if (trainManager != null) {
            trainManager.clear();
        }
        getLogger().info("MinecartPlus отключён.");
    }

    public TrainManager getTrainManager() {
        return trainManager;
    }
}
